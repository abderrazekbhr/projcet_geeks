import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  route: string;
  test:boolean=true;
  tab=["/Home","","/JoinUs","/Member","/Contact"];

  constructor(location: Location, router: Router) {
     this.route = location.path();
     console.log(this.route)
     this.test=this.tab.indexOf(this.route) > -1;//pour ne pas afficher nav et footer en cas de 404 ou d'echec!
    }


  ngOnInit() {
  }
}

