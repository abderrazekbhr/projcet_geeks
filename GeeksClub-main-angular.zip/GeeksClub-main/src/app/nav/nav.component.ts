import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {
activated:boolean=false;
click:boolean=true;
navig:boolean=true;
logo :String="../../assets/img/logo-geeks.png";
  constructor() { }

  ngOnInit(): void {
  }
  change:boolean=false;
  activer(){
   this.activated=!(this.activated);
   this.click=!this.click;
   this.navig=!this.navig;
  }

  @HostListener("document:scroll")
  scrollfunction(){
    if(document.body.scrollTop > 0 || document.documentElement.scrollTop > 0)
    this.change=true;
    else
    this.change=false;
  }
  onNotif(){
    this.click=!this.click;
    this.activated=!this.activated;
    this.navig=!this.navig;
  }
  onNotif2(){
this.navig=!this.navig;
this.click=!this.click;
this.activated=!this.activated;
  }
}
