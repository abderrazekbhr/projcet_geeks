import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AcceuilComponent } from './acceuil/acceuil.component';
import { AuthentificationGuard, DontPasseGuard } from './authentification.guard';
import { ContactComponent } from './contact/contact.component';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { EventComponent } from './event/event.component';
import { GeeksbureauComponent } from './geeksbureau/geeksbureau.component';
import { JoinComponent } from './join/join.component';
import { LoginComponent } from './login/login.component';
import { MainPaigeComponent } from './main-paige/main-paige.component';
import { NewMembersComponent } from './new-members/new-members.component';
import { Page404Component } from './page404/page404.component';

const routes: Routes = [

  { path: '', pathMatch: 'full', component: AcceuilComponent },
  { path: 'Acceuil', pathMatch: 'full', component: AcceuilComponent },
  { path: 'Contact', component: ContactComponent },
  { path: 'JoinUs', component: JoinComponent },
  { path: 'Member', component: LoginComponent },
  {path:'geeks-club-bureau-log-in',component:GeeksbureauComponent},
  {path:"dashbord",canActivate:[AuthentificationGuard],children:[
    {
      path:'', component: MainPaigeComponent
    },
    {
      path:'event', component: EventComponent
    },
    {
      path:'event-detail', component: EventDetailComponent
    },
    
  ]},
  { path: '**', component: Page404Component },
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
