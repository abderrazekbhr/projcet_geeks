import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) {
    
   }
   getAllMembers(){
    return this.http.get("http://localhost:8800/src/backend/getMembers.php");
   }
   addNewMembers(person:any):Observable<any>
   {
    return this.http.post("http://localhost:8800/src/backend/addNewMembers.php",person)}
   test(){
    return this.http.post("http://localhost:8800/src/backend/api.php",{"me":0});
   }
   login(info:any){
    return this.http.post("http://localhost:8800/src/backend/login.php",info)
   }
   sendEmail(mails:any){
    return this.http.post("http://localhost:8800/src/backend/login.php",mails)
   }
   updateScore(obj:any){
    return this.http.post("http://localhost:8800/src/backend/updateScore.php",obj);
   }
   getNewSore(obj:any){
    return this.http.post("http://localhost:8800/src/backend/score.php",obj);

  }
  passToIneterview(obj:any){
    return this.http.post("http://localhost:8800/src/backend/updateForInterview.php",obj);

  }
  sendManyMails(obj:any){
    return this.http.post("http://localhost:8800/src/backend/sendManyEmails.php",obj);

  }
}
