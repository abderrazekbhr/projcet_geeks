import { Component, OnInit} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {MatDialog} from '@angular/material/dialog';
import { NewMembersComponent } from '../new-members/new-members.component';
import { ApiService } from '../api.service';
import { NgForm } from '@angular/forms';


const ELEMENT_DATA:any[] = [];
@Component({
  selector: 'app-main-paige',
  templateUrl: './main-paige.component.html',
  styleUrls: ['./main-paige.component.css']
})
export class MainPaigeComponent implements OnInit {
  subject:string="";
  content:string="";
   dataSource :any;
   showFiller = false;

   obj:any=[];
   buttonDisabled:boolean;
   listStates:String[]=[];
   emailList:String[]=[];
  displayedColumns: string[] = ['check', 'name', 'prename', 'email','phone','state','detail'];

  constructor(public dialog: MatDialog,private service:ApiService) { }
  

  deferent(){
    for (let i=0;i<this.listStates.length;i++)
    {
      if(this.listStates[i]!=this.listStates[0])
      {
        return true
      }
    }
    return false
  }

  
  addMeToList(name:any,prename:any,mail:any,states:any){
    let i;
    if(this.emailList.indexOf(mail)!=-1){
      i=this.emailList.indexOf(mail)
      this.emailList.splice(i,1)
      this.obj.splice(i,1);
      this.listStates.splice(i,1);
    }
    else{
      this.emailList.push(mail)
      this.obj.push({
        'name':name,
        'prename':prename,
        'states':states,
        'email':mail
      })
      this.listStates.push(states);
    }
    this.buttonEtat();
  }


    buttonEtat()
    {
      if(this.deferent()==false && this.emailList.length!=0 && this.listStates[0]!="pre-inscription" )
      {
      this.buttonDisabled= false;
      }
      else{
        this.buttonDisabled= true;
      }
    }



  ngOnInit(): void {
  this.service.getAllMembers().subscribe(
    (res:any)=>{
      console.log(res["data"])
      for (let elt of res["data"]){
        ELEMENT_DATA.push(elt);
      }
      this.dataSource= new MatTableDataSource(ELEMENT_DATA)
      console.log(this.dataSource)
    },
    (err)=>{
      console.log(err);
    }
  )
  }



  openDialog(mail:string,name:string,prename:string,skills:string,dep:string,stars:string) {
    localStorage.setItem("mail",mail);
    localStorage.setItem("prename",prename);
    localStorage.setItem("name",name);
    localStorage.setItem("skills",skills);
    localStorage.setItem("dep",dep);
    console.log(mail)
    
    this.dialog.open(NewMembersComponent);
  }
  


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  logout(){
    localStorage.setItem("token","0");
  }

  sendMails(form:NgForm){
    this.service.sendManyMails({"email":form.value["mail"],"subject":form.value["subject"],"data":this.obj}).subscribe(
      (res:any)=>{
        console.log(res["sendMany"])
      }
      ,
      (err)=>{
        console.log(err);
      }
    )
  }

}
