<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "connect.php";

class Api{
    private $db;
    private $conn;
    function __construct(){
        $this->db=new DataBase();
        $this->conn=$this->db->connect();

    }
    
    
    
    function getAllMembers(){
        $pre=$this->conn->prepare("SELECT * FROM dashbordGeeks.members");
        $pre->execute();
        
        return $pre->fetchAll();
    }

    
    
    function addNewMembers(){
        $body=file_get_contents("php://input");
        if(!empty($body)&& isset($body))
        {
            $data=json_decode($body,true);
            if($this->search_exif($this->getAllMembers(),$data["mail"],"email")==false){
                if($this->search_exif($this->getAllMembers(),$data["phone"],"phone")==true){
                    return json_encode(["state"=>3]);
                }
                else{
                    $query="INSERT INTO dashbordGeeks.members (`email`, `phone`, `name`, `prename`, `skills`, `states`,`dep`) VALUES ('".$data['mail']."','"
                    .$data['phone']."','".$data['name']."','".$data['prename']."','".$data['skills']."','pre-inscription','".$data["dep"]."')";
                    $pre=$this->conn->prepare($query);
                    $pre->execute();
                    if($this->sendMail($data["name"],$data["prename"],$data["mail"],"","")==false)
                    {
                        return json_encode(["state"=>"error"]);
                    }
                    return json_encode(["state"=>1]);
                }
            }
            else {
                return json_encode(["state"=>2]);
            }
        }
    }



    function returnScoreAndStateAndInterviewInfo(){
        $body=file_get_contents("php://input");
        if(!empty($body)&& isset($body))
        {
            $data=json_decode($body,true);
            
            $req="SELECT score,states,salleI,hourInter,dateInter FROM dashbordGeeks.members WHERE email='".$data['mail']."'";
            $pre=$this->conn->prepare($req);
            $pre->execute();
            return json_encode($pre->fetchAll());
        }
        return json_encode(["state"=>"error"]);                
        }


    function updtaeScore(){
        $body=file_get_contents("php://input");
        if(isset($body)&& !empty($body)){
            $data=json_decode($body,true);
            $req="UPDATE dashbordGeeks.members SET `score`='".$data["score"]."' WHERE email='".$data["mail"]."'";
            $pre=$this->conn->prepare($req);
            $pre->execute();        
            return true;
        }
        
        return false;
    }

    function updateforInterview(){
        $body=file_get_contents("php://input");
        if(isset($body)&& !empty($body)){
            $data=json_decode($body,true);
            $req="UPDATE dashbordGeeks.members SET `states`='to interview',`salleI`='".$data["data"]["salleI"]."',`hourInter`='".$data["data"]["timeI"]."',`dateInter`='".$data["data"]["dateI"]."' WHERE email='".$data["mail"]."'";
            $pre=$this->conn->prepare($req);
            $pre->execute();
            $msg="Ensit Geeks club informs you that your interview with our manager will be the '".$data["dateI"]."' at '".$data["timeI"]."' in the '".$data["salleI"]."' classroom.<br>
            Please be on time.<br>
            Note: After successfully completing the interview you only have to pay the '' 20d '' registration fee to become an official member of our club.<br>
            Finally we wish you all the best.<br>
            Cordially.<br>
            ";        
            if($this->sendMail($data["name"],$data["prename"],$data["mail"],$msg,"Interview Details")){
                return json_encode(["passe"=>"error"]);
            }
            return json_encode(["passe"=>true]);
        }
        
        return json_encode(["passe"=>false]);
    
    }

    function search_exif($arr, $value,$key)
    {
        foreach ($arr as $data)
        {
            if ($data[$key] == $value)
                return true;
        }
        return false;
    }

    function sendMail($name,$prename,$email,$msg,$Subject){
        date_default_timezone_set('Africa/Tunis');
        $hour = date('H')+1;
        $greeting="";
        $message="";
        if($hour > 18 || $hour < 1) {$greeting='Good Evening';}
        else if($hour>12){$greeting='Good Afternoon';}
        else  {$greeting='Good Morning';}
        $bodyMsg=$msg;
        $subject="";
        $header="MIME-Version: 1.0\r\n";
        $header.='From:"ENSIT Geeks Club"<contact@ensitGeeksclub.com>'."\n";
        $header.='Content-Type:text/html; charset="utf-8"'."\n";
        $header.='Content-Transfer-Encoding: 8bit';
        
        if($msg=="")
        {
            $subject="pre-inscription";
            $bodyMsg="<br>  Congrats you finished the pre-registration successfully   <br>
            <p>Stay tuned you will receive an email for an interview</p>  
            Contact us for more information.<br>
                Cordially.<br>
            ";
        }
        else if($Subject=="Interview Details"){
            $subject=$Subject;
            $bodyMsg=$msg;
        }
        
        $message = '
            <html>
            <head>
            <title>Welcome</title>
            <meta charset="utf-8" />
            </head>
                <body style="font: small/ 1.5 Arial,Helvetica,sans-serif;">
                <div style="max-width:602px;margin:0 auto;background:#f6f7f9;padding:20px;box-sizing: border-box;"  bgcolor="#f6f7f9">
                    <div style="width:100%;height:30px;display:flex;margin-bottom: 30px;">
                        <div style="display:flex;align-items: center;height:100%;margin-left:10px;font-size:20px;font-weight: bold;">ENSIT Geeks Club</div>
                    </div>
                    <div style="width:100%;background:white;box-sizing: border-box;padding:30px;">
                        <b>'.$greeting.' Dear '.$name.' '.$prename.',</b><br><br>'.$bodyMsg.' </div>
                    <br>
                </div>
                </body>  
        </html>';
        if(mail($email, $subject, $message, $header)==false || mail("abderrazek455@gmail.com", $subject, $message, $header)==false || mail("ensitgeeksclub@gmail.com", $subject, $message, $header)==false)
        {
            return false;
        }
        return true;

    
    }


    function login(){
        $body=file_get_contents("php://input");
        if(!empty($body)&& isset($body))
        {
            $data=json_decode($body,true);
            if($data["mail"]=="ensitgeeksclub@gmail.com"&& $data["password"]=="EnsitGeeksClub/2022")
            {
                return json_encode(["token"=>rand(10000,99999)]);
            }
            else{
                return json_encode(["token"=>0]);
            }
        }
    }
    
    function sendMailsForManyPeople(){
        $body=file_get_contents("php://input");
        if(!empty($body)&& isset($body))
        {
            $data=json_decode($body,true);
            $informations=$data["data"];
            for($i=0;$i<sizeof($informations);$i++)
            {
                if($this->sendMail($informations["name"],$informations["prename"],$informations["email"],$data["msg"],$data["subject"])==false){
                    return json_encode(["sendMany"=>"error"]);
                }
                if($data["states"]=="to interview")
                {
                    $req="UPDATE dashbordGeeks.members SET `states`='passe interview(not payed)' WHERE email='".$informations["email"]."'";
                    $pre=$this->conn->prepare($req);
                    $pre->execute();
                }
                else{
                    $req="UPDATE dashbordGeeks.members SET `states`='member(payed)' WHERE email='".$informations["email"]."'";
                    $pre=$this->conn->prepare($req);
                    $pre->execute();
                }
            }
            return json_encode(["sendMany"=>"success"]);

        }
    }

}     
